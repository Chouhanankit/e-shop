import React, { useState } from 'react'


const SpecialMenu = () => {


    return (
        <>
            <h1 className="text-center text-red-400 display-3 h-[30vh]">SPECAIL MENU</h1>
        </>
    )
}

export default SpecialMenu
