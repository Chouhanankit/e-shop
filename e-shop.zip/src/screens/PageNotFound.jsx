import React from 'react'

const PageNotFound = () => {
    return (
        <>
            <div className="container p-10 h-5">
                <h1 className='text-2xl text-center text-red-500'>404 Page Not Found</h1>
            </div>
        </>
    )
}

export default PageNotFound