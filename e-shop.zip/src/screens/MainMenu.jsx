import React from 'react'
import ProductContainer from '../components/ProductContainer'

const MainMenu = () => {
    return (
        <>
           <ProductContainer/>
        </>
    )
}

export default MainMenu