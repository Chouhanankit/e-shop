import React from 'react'
import SpecialMenu from '../components/SpecialMenu'

const SpecialM = () => {
    return (
        <>
            <div className="container flex items-center justify-center mt-[8%]">
                <SpecialMenu />
            </div>
        </>
    )
}

export default SpecialM